# 1번 담당 v2 업로드 패치

이 폴더에서 `ecg_reconstruction/reports/role1_label_policy_v2_20261103/`만 기존 저장소 같은 경로에 추가하세요.
`.gitignore`는 새 CSV 예외 1개를 추가한 사본입니다. 기존 저장소의 `.gitignore`가 수정되어 있다면 사본 전체로 덮어쓰지 말고 새 예외 한 줄만 병합하세요.
원본 데이터/기존 모델/기존 결과는 수정하지 않습니다.
`LABEL_POLICY_V2.md` 확인 후 팀에서 승인하세요.
