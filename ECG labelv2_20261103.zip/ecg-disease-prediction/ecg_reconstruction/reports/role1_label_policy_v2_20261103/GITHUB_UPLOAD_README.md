# GitHub에 반영할 때

## 새 파일 위치
`ecg_reconstruction/reports/role1_label_policy_v2_20261103/`의 파일들만 새로 추가했습니다. 기존 `role1_label_audit_20261103` 및 `role2_summary_20261031` 폴더, 학습 코드, 데이터 분할, 이전 분류 결과는 변경하지 않았습니다.

기존 `.gitignore`가 `*.csv`를 제외하므로 프로젝트 루트 `.gitignore`에 다음 예외 한 줄을 추가했습니다.

```gitignore
!/ecg_reconstruction/reports/role1_label_policy_v2_20261103/tables/*.csv
```

## Git 명령 (기존 프로젝트 안에서)

```bash
git status
git add .gitignore ecg_reconstruction/reports/role1_label_policy_v2_20261103
git diff --cached --stat
git commit -m "Add versioned Role1 PTB-XL v2 label policy and audit"
git push origin main
```

`git push`는 본 패키지 생성 중 수행하지 않았습니다. 새 v2 기준은 **제안 상태**이며 기존 모델의 학습 정답을 자동으로 바꾸지 않습니다.
