# 1번 담당: 새 라벨 v2 결과물

**이번에 실제로 만든 별도 라벨 파일:** 원본 998개 ECG와 이전 분석/분할/모델 파일은 그대로 두고 `target_v2_*` 열로 정리한 새 연구용 라벨. **승인 전 제안**이며 의료 진단 정정이 아닙니다.

## 파일 안내

| 파일 | 내용 및 사용 시 주의 |
|---|---|
| `LABEL_POLICY_V2.md` | 사용 기준, 분할별 개수 및 근거를 기록한 정책표 |
| `tables/ecg_labels_v2_998.csv` | **권장 마스터**. 원본 18열 보존 + `target_v2_NORM` 등 새 열. 8개 미분류는 target 열 공란 |
| `tables/ecg_labels_v2_supervised_990.csv` | 990개 지도학습 후보만 추린 검토용 편의 파일. 998개 NPZ 파형과 **행 개수가 달라** ID로 매칭하지 않는 코드에 바로 넣으면 안 됨 |
| `tables/ecg_labels_v2_classifier_998.csv` | **향후 분류 재학습용 호환 파일**. 998개 ID 유지, `NORM,MI,STTC,CD,HYP` 열과 `diagnostic_classes`를 v2로 투영. 원본은 `source_...` 열 및 원본 `scp_codes`로 유지. **기존 v1 모델용 파일을 교체하지 말 것** |
| `tables/label_review_v2_36.csv` | 혼합 16 / 미분류 8 / likelihood 미상 14, 2개 겹침을 합친 36개. 제안, 근거, 검토자·결정란 |
| `tables/class_distribution_v1_v2.csv` | 원본/v2 Train·Validation·Test별 각 진단군 수·비율 및 변화 |
| `tables/status_by_split_v2.csv` | 998/990 분모, 미분류, 이진 정상·비정상, 혼합·likelihood 플래그 통계 |
| `tables/validation_v2.json` | 원본 파일 해시, 산출 파일 해시, 환자 중복 검사 및 수량 검증 |
| `scripts/build_v2_labels.py` | 원본 CSV를 읽어 위 결과를 생성하는 Python 표준 라이브러리 전용 코드. 원본 파일 쓰기 없음 |

## 추천 사용 순서

1. `LABEL_POLICY_V2.md`를 팀에서 검토하고 승인 여부를 결정합니다.
2. `ecg_labels_v2_998.csv`에서 `NORM`(원본)과 `target_v2_NORM`(새 정답)이 어떻게 다른지 확인합니다.
3. 3번 담당이 새 버전으로 다시 실험할 때는 기존 라벨 CSV를 덮어쓰지 말고, **명시적으로** `ecg_labels_v2_classifier_998.csv` 경로를 로딩하도록 설정합니다. 이 파일은 998개 ID를 유지하여 기존 998개 재구성 배열과 맞출 수 있습니다. 기존 `train_ecg_classification.py`는 전달된 데이터를 기본 경로에서 읽으므로 입력 경로 설정 변경이 필요할 수 있습니다.
4. 8개 제외 마스크를 적용하여 v2 supervised 대상 990개를 사용합니다. 분포와 지표는 v2 모델을 **재학습**해서 비교해야 합니다.
5. 반드시 Test를 새 모델의 임계값 선택/학습에 사용하지 마세요. 기존 분할 그대로 사용합니다.

### 재현 검증

프로젝트 루트에서:

```bash
python ecg_reconstruction/reports/role1_label_policy_v2_20261103/scripts/build_v2_labels.py --check
```

검증 통과 시 원본 데이터 유지, 998개/990개 수량, 환자 ID 분할 누출 없음, 원본 NORM 양성 545, 새 NORM 529, 검토 36개, 원본 진단군 불변이 확인됩니다. 재생성하려면 `--check`를 제거하면 됩니다.

**중요:** `prepare_dataset_1000.py` 자체를 수정하지 않았습니다. 임상 보고서 전문이나 원본 100Hz 파형 NPZ가 포함되지 않은 데이터에서는 SCP 원본 진단의 진위를 자동 재판정할 수 없습니다.
