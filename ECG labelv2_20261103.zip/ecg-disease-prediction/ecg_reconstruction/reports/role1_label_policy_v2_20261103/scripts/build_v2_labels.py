#!/usr/bin/env python3
"""Create versioned PTB-XL diagnostic labels without modifying original sources.

Runs with Python stdlib (no model training or patient data download).
Usage:
    python ecg_reconstruction/reports/role1_label_policy_v2_20261103/scripts/build_v2_labels.py
    python ecg_reconstruction/reports/role1_label_policy_v2_20261103/scripts/build_v2_labels.py --check
"""
from __future__ import annotations
import argparse
import ast
import collections
import csv
import hashlib
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / "role2_summary_20261031" / "tables"
OUT = ROOT / "tables"
V = "role1_v2.0_proposed_2026-11-03"
CLASS = ("NORM", "MI", "STTC", "CD", "HYP")
DISEASE = CLASS[1:]
SPLITS = ("train", "validation", "test")
SOURCE_FILES = (
    "ecg_labels_all_1000.csv",
    "ecg_labels_analysis_998.csv",
    "dataset_split_998.csv",
    "code_details.csv",
    "label_review.csv",
)


def assert_that(cond, why):
    if not cond:
        raise AssertionError(why)


def load(name):
    with (SOURCE / name).open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def csv_bytes(rows, cols):
    f = io.StringIO(newline="")
    writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return ("\ufeff" + f.getvalue()).encode("utf-8")


def sha256(contents):
    return hashlib.sha256(contents).hexdigest()


def require_file(output, data, check):
    path = OUT / output
    if check:
        assert_that(path.is_file(), f"Missing output: {path}")
        assert_that(path.read_bytes() == data, f"Output differs from deterministic source: {output}")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def label_status(r, targets):
    if not targets:
        return "outside_5class_unsupervised"
    positive = {c for c in CLASS if targets[c] == 1}
    if positive == {"NORM"}:
        return "normal_only"
    if len(positive) > 1:
        return "multiple_disease_classes"
    return "disease_class_present"


def main(check=False):
    # Completely read-only source inputs; compare source hashes before and after.
    before = {name: sha256((SOURCE / name).read_bytes()) for name in SOURCE_FILES}
    inv = load("ecg_labels_all_1000.csv")
    src = load("ecg_labels_analysis_998.csv")
    splits = load("dataset_split_998.csv")
    details = load("code_details.csv")
    old_review = load("label_review.csv")
    assert_that(len(inv) == 1000 and len(src) == 998 and len(splits) == 998,
                "Unexpected data counts. Do not silently apply policy to different dataset.")
    assert_that(len({r['ecg_id'] for r in src}) == 998, "Duplicate ECG ID")
    assert_that(len({r['patient_id'] for r in src}) == 998, "This fixed version assumes 1 ECG per patient")
    assert_that({r['ecg_id'] for r in inv} - {r['ecg_id'] for r in src} == {'421','710'},
                "Historical quality exclusions unexpectedly changed")
    assert_that({r['ecg_id'] for r in splits} == {r['ecg_id'] for r in src}, "Split ID mismatch")
    split_map = {r['ecg_id']:r for r in splits}
    patient_by_split = collections.defaultdict(set)
    for r in src:
        assert_that(r['split'] in SPLITS, f"Invalid split {r['ecg_id']}")
        assert_that(r['patient_id'] == split_map[r['ecg_id']]['patient_id']
                    and r['split'] == split_map[r['ecg_id']]['split'], f"Split inconsistent {r['ecg_id']}")
        patient_by_split[r['split']].add(r['patient_id'])
    for i, s in enumerate(SPLITS):
        for t in SPLITS[i+1:]:
            assert_that(not patient_by_split[s] & patient_by_split[t], f"Cross-split patient leak: {s} vs {t}")
    assert_that(dict(collections.Counter(r['split'] for r in src)) ==
                {'train':798,'validation':100,'test':100}, "Original counts changed")

    zero_codes = collections.defaultdict(list)
    for d in details:
        if d['diagnostic'] in ('1','1.0') and float(d['likelihood']) == 0.0:
            zero_codes[d['ecg_id']].append(d['code'])

    review_expected = {r['ecg_id'] for r in old_review}
    records = []
    reviewed = []
    v2_pos = {s:collections.Counter() for s in ('all',)+SPLITS}
    old_pos = {s:collections.Counter() for s in ('all',)+SPLITS}
    issue_sets = collections.defaultdict(set)
    for r in sorted(src, key=lambda row:(SPLITS.index(row['split']), int(row['ecg_id']))):
        eid = r['ecg_id']
        original = {c: int(r[c]) for c in CLASS}
        assert_that(all(x in (0,1) for x in original.values()), f"Nonbinary original label {eid}")
        parsed = ast.literal_eval(r['scp_codes'])
        assert_that(isinstance(parsed, dict), f"Invalid source SCP dict {eid}")
        classes_from_text = set(filter(None, r['diagnostic_classes'].split(';')))
        assert_that(classes_from_text == {c for c in CLASS if original[c]},
                    f"SCP classes do not agree with original columns {eid}")
        assert_that(all(x in parsed for x in filter(None,r['diagnostic_codes'].split(';'))),
                    f"SCP code mapping mismatch {eid}")
        zeros = sorted(zero_codes.get(eid, []))
        # Only 5 class labels are in scope. No class => supervised labels undefined.
        eligible = int(any(original.values()))
        mixed = int(original['NORM'] == 1 and any(original[c] for c in DISEASE))
        if eligible:
            target = dict(original)
            if any(original[c] for c in DISEASE):
                target['NORM'] = 0
            binary = str(int(any(target[c] for c in DISEASE)))
        else:
            target = {}  # blank, not negative zero: never train on unlabeled ECG
            binary = ''
        reasons = []
        if mixed:
            reasons.append('mixed_NORM_with_disease')
        if not eligible:
            reasons.append('outside_selected_five_classes')
        if zeros:
            reasons.append('unknown_diagnostic_likelihood')
        for reason in reasons:
            issue_sets[reason].add(eid)
        status = label_status(r,target)
        added = {
            'label_policy_version': V,
            'supervised_eligible_v2': str(eligible),
            'reconstruction_eligible_v2': '1',
            **{f'target_v2_{c}': str(target[c]) if eligible else '' for c in CLASS},
            'binary_target_v2':binary,
            'label_status_v2': status,
            'mixed_NORM_with_disease':str(mixed),
            'unknown_diagnostic_likelihood':str(int(bool(zeros))),
            'zero_likelihood_diagnostic_codes':';'.join(zeros),
            'review_required_v2':str(int(bool(reasons))),
            'review_reasons_v2':';'.join(reasons),
        }
        out = {**r,**added}
        records.append(out)
        for s in ('all',r['split']):
            for c in CLASS:
                old_pos[s][c] += original[c]
                if eligible:
                    v2_pos[s][c] += target[c]
        if reasons:
            if not eligible:
                decision = 'retain_original; exclude_only_from_5class_supervised_v2; do_not_assume_normal'
                why = 'No labels in the selected five diagnostic superclasses (PACE/AFLT may be out of scope).'
            elif mixed:
                decision = 'retain_original; set_only_target_v2_NORM_to_0; keep_diseases'
                why = 'NORM is defined as no disease only for v2 target, while source diagnostic codes remain unchanged.'
            else:
                decision = 'retain_source_diagnostic_labels; flag_unknown_likelihood'
                why = 'PTB-XL likelihood 0 means certainty unknown, not negative; review in sensitivity analysis.'
            if zeros:
                why += ' Diagnostic codes with unknown likelihood: ' + ';'.join(zeros) + '.'
            reviewed.append({
                'ecg_id':eid,'patient_id':r['patient_id'],'split':r['split'],
                'original_scp_codes':r['scp_codes'],
                'original_diagnostic_codes':r['diagnostic_codes'],
                'original_diagnostic_classes':r['diagnostic_classes'],
                **{f'original_{c}':str(original[c]) for c in CLASS},
                **{f'target_v2_{c}':added[f'target_v2_{c}'] for c in CLASS},
                'supervised_eligible_v2':str(eligible),
                'binary_target_v2':binary,
                'review_reasons_v2':';'.join(reasons),
                'zero_likelihood_diagnostic_codes':';'.join(zeros),
                'proposed_rule':decision,
                'rationale':why,
                'reviewer':'','decision':'','decision_date':'',
                'decision_status':'proposal_pending_team_approval',
            })
    assert_that(len(records)==998, 'Incorrect v2 total')
    assert_that(len(reviewed)==36, 'Expected 36 review rows')
    assert_that({r['ecg_id'] for r in reviewed}==review_expected, 'Original review record set not preserved')
    assert_that({k:len(v) for k,v in issue_sets.items()}=={
        'mixed_NORM_with_disease':16,'outside_selected_five_classes':8,
        'unknown_diagnostic_likelihood':14}, 'Issue counts inconsistent')
    assert_that(len(issue_sets['mixed_NORM_with_disease'] & issue_sets['unknown_diagnostic_likelihood'])==2,
                'Expected two overlap rows')
    eligible = [r for r in records if r['supervised_eligible_v2']=='1']
    assert_that(len(eligible)==990, 'Expected 990 supervised targets')
    assert_that(sum(int(r['NORM']) for r in records)==545, 'Original NORM count changed')
    assert_that(sum(int(r['target_v2_NORM'] or 0) for r in records)==529,
                'NORM change must be limited to 16 mixed records')
    assert_that(sum(int(r['NORM']) != int(r['target_v2_NORM']) for r in eligible)==16,
                'Unexpected number of NORM modifications')
    for r in eligible:
        for c in DISEASE:
            assert_that(r[c] == r['target_v2_'+c], f"Disease label unintentionally changed {r['ecg_id']}")
        assert_that(not (r['target_v2_NORM']=='1' and any(r['target_v2_'+c]=='1' for c in DISEASE)),
                    f"NORM coexistence persists in v2 targets {r['ecg_id']}")
    for r in records:
        if r['supervised_eligible_v2']=='0':
            assert_that(all(r['target_v2_'+c]=='' for c in CLASS) and r['binary_target_v2']=='',
                        f"Out-of-scope row incorrectly has negative class labels {r['ecg_id']}")

    columns = list(src[0]) + [k for k in records[0] if k not in src[0]]
    review_columns = list(reviewed[0])
    row_stats = []
    for split in ('all',)+SPLITS:
        part = records if split=='all' else [r for r in records if r['split']==split]
        incl = [r for r in part if r['supervised_eligible_v2']=='1']
        for c in CLASS:
            o = old_pos[split][c]
            v = v2_pos[split][c]
            row_stats.append({
                'split':split,'label':c,'original_count':str(o),
                'original_denominator_998_split':str(len(part)),
                'original_pct':f'{100*o/len(part):.2f}',
                'target_v2_count':str(v),
                'supervised_v2_denominator':str(len(incl)),
                'target_v2_pct':f'{100*v/len(incl):.2f}',
                'delta_count':str(v-o),
                'note':'Multi-label disease groups can overlap; percentages can sum above 100.'
            })
    row_stats_cols = list(row_stats[0])
    record_stats = []
    for split in ('all',)+SPLITS:
        part = records if split=='all' else [r for r in records if r['split']==split]
        included = [r for r in part if r['supervised_eligible_v2']=='1']
        normal = sum(r['target_v2_NORM']=='1' for r in included)
        abnormal = sum(r['binary_target_v2']=='1' for r in included)
        record_stats.append({
            'split':split,'reconstruction_total':str(len(part)),
            'v2_supervised_total':str(len(included)),
            'unclassified_excluded_from_supervised':str(len(part)-len(included)),
            'normal_only_v2':str(normal), 'abnormal_v2':str(abnormal),
            'mixed_source_NORM_disease':str(sum(r['mixed_NORM_with_disease']=='1' for r in part)),
            'unknown_likelihood_diagnostic':str(sum(r['unknown_diagnostic_likelihood']=='1' for r in part)),
            'unique_patients':str(len({r['patient_id'] for r in part})),
        })
    record_stat_cols = list(record_stats[0])
    assert_that({r['split']:(int(r['v2_supervised_total']),int(r['normal_only_v2']),int(r['abnormal_v2']))
                 for r in record_stats if r['split']!='all'} ==
                {'train':(796,434,362),'validation':(96,48,48),'test':(98,47,51)},
                'Supervised target counts differ from expected source status')

    # Dedicated copy for future v2 classifier experiments. Keep 998 IDs so it can
    # match the original NPZ; only its label columns are projected from v2 targets.
    # SCP codes and original label metadata are preserved in separate source_* cols.
    classifier_records = []
    for r in records:
        c = dict(r)
        c['source_diagnostic_classes'] = r['diagnostic_classes']
        c['source_label_status'] = r['label_status']
        c['source_has_multiple_classes'] = r['has_multiple_classes']
        for cl in CLASS:
            c['source_'+cl] = r[cl]
            c[cl] = r['target_v2_'+cl] if r['supervised_eligible_v2']=='1' else '0'
        classes_now = [cl for cl in CLASS if c[cl]=='1']
        c['diagnostic_classes'] = ';'.join(classes_now)
        c['has_multiple_classes'] = str(len(classes_now)>1)
        c['label_status'] = r['label_status_v2']
        classifier_records.append(c)
    classifier_cols = columns + ['source_diagnostic_classes','source_label_status',
                                  'source_has_multiple_classes'] + ['source_'+cl for cl in CLASS]
    assert_that(len(classifier_records)==998 and sum(int(r['NORM']) for r in classifier_records)==529,
                'V2 classifier view wrong normal target count')
    for c in classifier_records:
        assert_that({k for k in CLASS if c[k]=='1'} == set(filter(None,c['diagnostic_classes'].split(';'))),
                    f'Classifier label list disagrees with columns: {c["ecg_id"]}')
        assert_that(c['scp_codes'] == next(r['scp_codes'] for r in records if r['ecg_id']==c['ecg_id']),
                    f'Source SCP code unintentionally changed: {c["ecg_id"]}')

    payloads = {
        'ecg_labels_v2_classifier_998.csv':csv_bytes(classifier_records,classifier_cols),
        'ecg_labels_v2_998.csv':csv_bytes(records,columns),
        'ecg_labels_v2_supervised_990.csv':csv_bytes(eligible,columns),
        'label_review_v2_36.csv':csv_bytes(reviewed,review_columns),
        'class_distribution_v1_v2.csv':csv_bytes(row_stats,row_stats_cols),
        'status_by_split_v2.csv':csv_bytes(record_stats,record_stat_cols),
    }
    for name,contents in payloads.items():
        require_file(name,contents,check)
    after = {name:sha256((SOURCE/name).read_bytes()) for name in SOURCE_FILES}
    assert_that(before==after,'Source files mutated unexpectedly!')
    metadata = {
        'policy_version':V,'policy_status':'PROPOSED_NOT_CLINICALLY_VALIDATED',
        'source_files_sha256':before,
        'generated_sha256':{name:sha256(b) for name,b in payloads.items()},
        'validation':{
            'source_inventory':1000,'source_analysis':998,'source_excluded_ids':['421','710'],
            'train':798,'validation':100,'test':100,
            'v2_supervised':990,'v2_unclassified_masked':8,
            'mixed_norm_source':16,'v2_norm_set_to_0':16,
            'original_norm_count':545,'v2_norm_count':529,
            'unknown_likelihood_flagged':14,
            'unique_review_records':36,'review_overlap_mixed_and_unknown':2,
            'train_validation_test_patient_overlap':0,
            'original_source_files_changed':0,
            'disease_label_changes':0,'original_label_changes':0,
        },
        'warning':'V2 derived research labels. No clinical diagnostic reinterpretation. V1 models need new training for V2.'
    }
    require_file('validation_v2.json', (json.dumps(metadata,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode('utf-8'),check)
    print(json.dumps(metadata['validation'],ensure_ascii=False,indent=2))
    print('OK: '+ ('outputs match read-only inputs' if check else 'v2 outputs written'))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--check',action='store_true',help='verify generated outputs exactly match source data')
    args=parser.parse_args()
    main(args.check)
